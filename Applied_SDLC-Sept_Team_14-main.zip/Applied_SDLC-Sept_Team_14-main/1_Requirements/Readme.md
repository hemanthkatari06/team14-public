# INTRODUCTION

## Welcome to Scientific Calculator 
Modern scientific calculators generally have many more features than a standard four or five-function calculator, and the feature set differs between manufacturers and models; however, the defining features of a scientific calculator include - 
* Arithmetic functions
* Scientific functions
* Trigonometric Functions
* Matrix Function

In this miniproject we implementing some of those features along with certain other conversion calculators using C programming which will operate on both Windows and Linux operating systems.

## RESEARCH

The Scientific calculator doesn't involve any complex operations or any operations. It is easy to apply the values in the system to find the required result rather than remembering and applying it in formula. Thus by studying all these facts, the necessary functions have been implemented to get the required results in a better way.

## FEATURES AND DESCRIPTION 

| Serial No | Feature | Description |
| ---- | ------ | ---------- |
| 1 | Addition | sum() takes two values as input and returns x+y |
| 2 | Subtraction | substraction() takes two values as input and returns x-y |
| 3 | Multiplication | multiplication() takes two values as input and returns x * y | 
| 4 | Division | division() takes two values as input and returns x/y and x%y |
| 5 | Power | power() takes two values as input and returns x ^ y |
| 6 | Log | logbase10() takes a value and returns log 10(x) |
| 7 | Exponent | exponent() takes a value and returns e^ x |
| 8 | Squareroot | squareroot() takes a value and returns √x |
| 9 | Sin | sine() takes a value which is in radian and return sin(x) |
| 10 | Cos | cosine() takes a value which is in radian and return cos(x) |
| 11 | Tan | tan() takes a value which is in radian and return tan(x) |
| 12 | Cosec | cosec() takes a value which is in radian and return cosec(x) |
| 13 | Sec | sec() takes a value which is in radian and return sec(x) |
| 14 | Cot | cot() takes a value which is in radian and return cot(x) |
| 15 | Temperature Converter | Celsius to Fahrenheit , Fahrenheit to Kelvin , Kelvin to Celsius |
| 16 | Energy converter | Conversion btw Joules, KiloJoules, Watt and kiloWatts |
| 17 | Length converter | Conversion between different unit of length|
| 18 | Time converter | Conversion between different units of time (seconds, minutes and hours) |
| 19 | Speed converter | To convert speed units from m/s to km/hr and vice versa |
| 20 | BMI calculator | Takes input of the weight, height and calculate BMI |
| 21 | Birth calculator | To take input of DOB and calcuate age |
| 22 | Currency converter | To convert different currency to rupees |
| 23 | Weight converter | Conversion between different unit of weight|
| 24 | Matrix Addition | Addition of Two Matrices |
| 25 | Matrix Subtraction | Subtraction of Two Matrices |
| 26 | Matrix Multiplication | Multiplication of Two Matrices |
| 27 | Matrix Division | Division of Two Matrices |
| 28 | Linear Equations to Matrix | Representing Linear Equations in Matrix form | 
| 29 | Simple Interest | Calculating Simple Interest for given values of principle,time and rate |
| 30 | Compound Interest | Calculating Compound Interest for given values of principle,time and rate |


## SWOT ANALYSIS

![Swot Analysis](https://user-images.githubusercontent.com/67146750/135448026-83a70201-bc3e-437e-89ef-5e2468e258df.jpeg)

# 4W's and 1'H
## Who:
 * Any user who want to perform various operations at one place.

## What:
* By using the calculator user can perform the basic calculations ,scientific calculations ,conversions and other calculations.

## When:
* User can use this at any time for performing various opperations.

## Where:
* Any user who has a computer with him.

## How:
* The usage of this project is very simple as it is an input output application. The user just need to choose the correct number for the operation to be performed.


## Detail Requirements

### High Level Requirements 
| ID | Description | Status (Implemented/Future) | 
| ----- | ----- | ---------|
| HR_01 | User will be able to perform Arthimetic Operations | Implemented| 
| HR_02 | User will be able to perform scientific operations | IImplemented |
| HR_03 | User will be able to perform matrix operations | Implemented |
| HR_04 | User will be able to perform various other operations/conversions | Implemented |
| HR_05 | User will be able to perform Interest calculations | Implemented |

### Low level Requirements
| ID | Description | HLR ID | Status (Implemented/Future) |
| ------ | --------- | ------ | ----- |
| LR_01 | Permorming Addition | HR01 | Implemented |
| LR_02 | Performing Subtraction | HR01 | Implemented |
| LR_03 | Performing Multiplication | HR01 | Implemented |
| LR_04 | Performing Division | HR01 | Implemented |
| LR_05 | Performing Power | HR01 | Implemented |
| LR_06 | Performing Logarithm | HR01 | Implemented |
| LR_07 | Performing Exponent of a number | HR01 | Implemented |
| LR_08 | Performing Squareroot of a number | HR01 | Implemented |
| LR_09 | Performing Sine function | HR02 | Implemented |
| LR_10 | Performing Cosine function | HR02 | Implemented |
| LR_11 | Performing Tangent function | HR02 | Implemented |
| LR_12 | Performing Cosecant function | HR02 | Implemented |
| LR_13 | Performing Secant function | HR02 | Implemented |
| LR_14 | Performing Cotangent function | HR02 | Implemented |
| LR_15 | Performing conversions in Temperature between various units | HR03 | Implemented |
| LR_16 | Performing conversions in Energy between various units | HR03 | Implemented |
| LR_17 | Performing conversions in Length between various units | HR03 | Implemented |
| LR_18 | Performing conversions in Time between various units | HR03 | Implemented |
| LR_19 | Performing conversions in Speed between various units | HR03 | Implemented |
| LR_20 | Calculating the BMI by taking the input as weight and height | HR03 | Implemented |
| LR_21 | Calculating the age by taking input as Date of Birth | HR03 | Implemented |
| LR_22 | Performing conversions in Currency between various units | HR03 | Implemented |
| LR_23 | Performing conversions in Weight between various units | HR03 | Implemented |
| LR_24 | Performing Adddition between two matrices | HR04 | Implemented |
| LR_25 | Performing Subtraction between two matrices | HR04 | Implemented |
| LR_26 | Performing Multiplication between two matrices | HR04 | Implemented |
| LR_27 | Performing Division between two matrices | HR04 | Implemented |
| LR_28 | Represents Linear Equations in Matrix Form | HR04 | Implemented |
| LR_29 | Performing Simple Interest calculations | HR05 | Implemented |
| LR_30 | Performing Compound Interest calculations | HR05 | Implemented |
***************************************************************************
