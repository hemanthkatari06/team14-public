# TEST PLAN:

## Table no: High level test plan

| **Test ID** | **Description**                                              | **Expected Input** | **Expected Output** | **Actual Out** |   
|-------------|--------------------------------------------------------------|------------|-------------|----------------|
|  HLT_01       | Arithmetic operations | Choice  | Implemented | Success | 
|  HLT_02      | Scientific operations | Choice  | Implemented | Success |
|  HLT_03      | Matrix operations  | Choice  | Implemented | Success |
|  HLT_04      | Converter operations  | Choice | Implemented | Success |
|  HLT_05      | Interest calculations  | Choice  | Implemented | Success |



## Table no: Low level test plan

| **Test ID** |  **Description**                                                  | **Expected Input** | **Expected Output** | **Actual Out** |    
|-------------|-------------------------------------------------------------------|------------|-------------|----------------|
|LLT_01|Addition of two numbers|2,3|5|5|
|LLT_02|Subtraction of two numbers|3,2|1|1|
|LLT_03|Multiplication of two numbers|2,3|6|6|
|LLT04|Division of two numbers|15,5|3|3|
|LLT_05|power of a number|2,3|8|8|
|LLT_06|sine function|0|0|0|
|LLT_07|cosine function|0|1|1|
|LLT_08|tan function|0|0|0|
|LLT_09|secant function|0|1|1|
|LLT_10|cosecant function|30|2|2|
|LLT_11|cotangent|45|1|1|
|LLT_12|temperature conversion from celcius to fahrenheit|45|113.00|1113.00|
|LLT_13|energy conversion from jopules to kilojoules|155|1.5|1.5|
|LLT_14|length conversion from centimeters to meters|100|1|1|
|LLT_15|time conversion from minutes to hours|60|1|1|
|LLT_16|speed conversion from meters/second to kilometers/hour |1|3.6|3.6|
|LLT_17|currency conversion from dollar to euro |1|0.848|0.848|
|LLT_18|weight conversion from gram to kilogram|1000|1|1|
|LLT_19|age calculator|2021-10-09, 2000-08-30|21 years 2 weeks 2days old|21 years 2 weeks 2days old|
|LLT_20|bmi calculator|135, 37|0.002030|0.002030|
|LLT_20|simple interest|1000,3, 7|210|210|
|LLT_20|compund interest|1000,5, 3|1159.27|1159.27|
