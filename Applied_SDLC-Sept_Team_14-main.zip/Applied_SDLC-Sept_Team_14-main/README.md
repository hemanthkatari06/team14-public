# Applied_SDLC-Sept_Team_14
## Digital Calculator - Intro
The project titled Digital Calculator is developed using C programming concepts. In this project, we have tried to implement the existing scientific calculator functions which consists of-
* basic arithmetic functions(add, subtract, multiply, divide, square root, power)
* trigonometric funtions(sin, cos, tan)
* alongwith certain other functions.

To not be in the mainstream, we have added some other functions in our digital calculator, such as-
* conversion calculator(mass, length, time, speed, temperature, energy, BMI etc conversions between respective units)
* matrix calculator(addition, subtraction, multiplication and division of matrices)
* interest calculator(simple and compound interest calculator)
* trigonometric funtions(also included cosec, sec, cot)

Our Digital Calculator has 5 main functions - Simple Calculator, Scientific Calculator, Matrix Calculator, Conversion Calculator and Interest Calculator. All the sub functions are declared and defined inside these five functions. We have given our best practice for Requirements Gathering. Behavioral and structural diagrams give a clear view of the functioning of our Calculator. The flow chart depicts the flow of code and its working. Code is generated using multifile approach and test files are attached to check the operation of functions.

## Digital Calculator - Representation
![Screenshot (153)](https://user-images.githubusercontent.com/89648206/135748442-87771774-1817-4f4f-a078-2c60b74b30bb.png)

## Contributors List
|PS no. |  Name   |Contribution|
|-------|---------|------------------------------- |
| `40019108` | Bamini Varalaxmi |In REQUIREMENTS, I did SWOT analysis, main READ.ME and BMI unit testing in IMPLEMENTATION and Low Level Requirements in TEST PLAN                    |    
| `40019113` | Dasari Teja Sai |In Requirements,and I involved in SWOT analysis, main READ.ME and TIME unit testing in IMPLEMENTATION and description part      |
| `40019117` | Dasineni Sri Narasimha |  In REQUIREMENTS, and I Involved in SWOT Analysis, main READ.ME and Mass, simple calculator unit testing and description part.          |
| `40019134` | Suhas K N |  In Requirements,and I involved in SWOT analysis, main READ.ME and Birth calculator and linear to matrix conversion and its unit testing .                  |
| `40019144` | Venkata Hemanth Kumar Katari |  Involved in Requirements gathering, Swot analysis, making Multifile, Makefile and also I am done with matrix operations unit testing   |
| `40019153` | Nandyala Jagannath Sravan |In requirements, 4w's and 1'h, high level and low level requirements. In implementation part I did currency, energy & length functions and I committed unit test files in TEST|
| `40018618` | Pooja Bayagalli |   Involved in making makefile,multifile and done matrix operation i.e addition and subtraction.                | 
| `40019160` | Kajal Awasthi | Provided introduction to our project in main readme. Contributed temperature, speed, numberconversion codes in the implementation part and behavioral and structural diagrams alongwith flow chart in the Design part                    |
| `40019187` | Kattula Neha | In REQUIREMENTS, I did SWOT analysis, features and description. In implementation I committed  Trigonometric function and simple interest                   |
| `40019197` | Maddala Sai Durga Kalyani |   In requirements, I involved in swot analysis,high level and low level and in implementations i committed the main.c functions and matrix operations      |
| `40019074` | Sadanand Rayar | Involved in making SWOT analysis,multifile and done with unit testing of Compound Interest.                  |

## Folder Structure
Folder                   | Description
-------------------------| -----------------------------------------
`1_Requirements`         | Documents detailed requirements
`2_design`         | Behavioural and Structural UML Diagrams(Both High Level and Low Level)
`3_Testplan`       | Documents with test plans and procedures and Output
`4_Implementation`     | All codes and Simulation
`5_Report_video`               | Documentation of whole project
`6_standup_Other`     | Other files<br />
## Badges
### 
| Name | Badge |
| :--: | :--:  |
| CI |   [![C/C++ CI](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/c-cpp.yml/badge.svg)](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/c-cpp.yml)  |
|   Git Inspector |    [![Contribution Check - Git Inspector](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/gitinspector.yml/badge.svg)](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/gitinspector.yml)    |
|   Code Quality |   [![Code Quality - Static Code - Cppcheck](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/cppcheck.yml/badge.svg)](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/cppcheck.yml)  |
|  Unit Testing  |   [![Unit testing](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/UnitTesting.yml/badge.svg)](https://github.com/GENESIS2021Q1/Applied_SDLC-Sept_Team_14/actions/workflows/UnitTesting.yml) |
