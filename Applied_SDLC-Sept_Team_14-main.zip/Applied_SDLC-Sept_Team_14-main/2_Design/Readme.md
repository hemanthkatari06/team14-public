# Architecture

* Add UML Diagrams
* For information about UML Diagrams refer: [UML Diagrams](https://www.uml-diagrams.org/uml-25-diagrams.html)

## Tools

* [Draw.io](https://app.diagrams.net/)
* [Creately](https://app.creately.com/diagram/create)
* or any other free tools

## Use Case Diagram

![Use_case](https://user-images.githubusercontent.com/89745488/136451562-3fd83626-f1cb-45b1-8e24-94aa60f4d6fc.png)


## Activity Diagram

![activity_diagram](https://user-images.githubusercontent.com/89745488/135492241-2ce9b682-983f-459f-8698-77a6c83390d0.jpg)

## Class Diagram

![Class Diagram](https://user-images.githubusercontent.com/89745488/136338838-1e3d4e46-b9a1-489f-922b-d11f6e7aadb4.png)

## Flow Chart
![FlowChart](https://user-images.githubusercontent.com/89745488/136449731-d2e9d596-0dc2-4b60-83e6-317e4e8cba54.png)
