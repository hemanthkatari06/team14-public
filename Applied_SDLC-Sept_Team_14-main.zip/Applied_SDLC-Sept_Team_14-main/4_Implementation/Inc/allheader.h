#ifndef ALLHEADER_H_INCLUDED
#define ALLHEADER_H_INCLUDED
#include <stdio.h>
#include<stdlib.h>

int add(int a,int b);
void addition_test();
int subs(int a,int b);
void sub_test();
int mul(int a,int b);
void multi_test();
int divide(int a,int b);
void division_test();
//---------------------------
int power(int a,int b);
void power_test();
int sqroot(int a);
void squareroot_test();
//----------------------------
float centigram_gram(int a);
float centigram_kilogram(int a);
float gram_kilogram(int a);
int gram_centigram(int a);
int kilogram_centigram(int a);
int kilogram_gram(int a);
void centigram_to_gram_test();
void centigram_to_kilogram_test();
void gram_to_kilogram_test();
void gram_to_centigram_test();
void kilogram_to_centigram_test();
void kilogram_to_gram_test();
#endif // ALLHEADER_H_INCLUDED
