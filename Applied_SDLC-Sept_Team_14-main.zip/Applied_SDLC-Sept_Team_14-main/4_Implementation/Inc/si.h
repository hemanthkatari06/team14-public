#ifndef __SI_H__
#define __SI_H__

#include<stdio.h>
#include<string.h>
#include<math.h>
#include<conio.h>
#include<windows.h>
#include<time.h>
#include<stdlib.h>
#define PI 3.14159265

int simple();



#endif
