# Output Images

### output images
![outputimage1](https://user-images.githubusercontent.com/89761761/136646752-95327a05-2a03-4436-92d1-6db088e790d6.png)
![outputimage2add](https://user-images.githubusercontent.com/89761761/136646783-a148236c-2ee2-4c1a-912a-85002331d220.png)
![outputimage3sin](https://user-images.githubusercontent.com/89761761/136646794-002e66d1-234b-4729-9a8f-4f2299509aa8.png)
![outputimage4matadd](https://user-images.githubusercontent.com/89761761/136646799-5f8f8bd6-d42a-49b7-81d4-3d307ee7066f.png)
![WhatsApp Image 2021-10-09 at 11 48 55 AM](https://user-images.githubusercontent.com/89761761/136646829-dfe78b8a-4fe3-40f8-a17e-b9f7fcb5d6be.jpeg)
![WhatsApp Image 2021-10-09 at 11 48 54 AM](https://user-images.githubusercontent.com/89761761/136646843-d6a6ea08-cc82-4988-9b0f-cb913d8c14d7.jpeg)
![outputimage7si](https://user-images.githubusercontent.com/89761761/136646861-614fd764-ec6d-4c2d-a494-790b71594f6d.png)








### Unit test cases


